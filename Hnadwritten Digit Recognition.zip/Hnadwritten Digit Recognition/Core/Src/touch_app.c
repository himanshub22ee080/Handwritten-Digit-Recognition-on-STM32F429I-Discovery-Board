/*
 * touch_app.c
 *
 *  Created on: Apr 1, 2020
 *  Himanshu Sharma
 *  B22EE080
 */

#include "global.h"
#include <stdio.h>
#include <string.h>

// --- Include AI Header ---
#include "app_x-cube-ai.h"
#include "ai_datatypes_defines.h"

// --- Include Timer Header --- REMOVED ---
// #include "tim.h"

// --- Extern Timer Handle --- REMOVED ---
// extern TIM_HandleTypeDef htim1;

// --- State Management ---
typedef enum {
    APP_STATE_MAIN,
    APP_STATE_COLOR_SELECT
} AppState;

static volatile AppState currentAppState = APP_STATE_MAIN; // Track the current screen

// --- Color Data ---
typedef struct {
    uint32_t colorValue;
    const char* colorName; // Optional: For potential future use/debug
} ColorInfo;

// Array holding all available colors from your list
const ColorInfo availableColors[] = {
    {LCD_COLOR_BLUE,        "BLUE"},       {LCD_COLOR_GREEN,       "GREEN"},
    {LCD_COLOR_RED,         "RED"},        {LCD_COLOR_CYAN,        "CYAN"},
    {LCD_COLOR_MAGENTA,     "MAGENTA"},    {LCD_COLOR_YELLOW,      "YELLOW"},
    {LCD_COLOR_LIGHTBLUE,   "LT BLUE"},    {LCD_COLOR_LIGHTGREEN,  "LT GREEN"},
    {LCD_COLOR_LIGHTRED,    "LT RED"},     {LCD_COLOR_LIGHTCYAN,   "LT CYAN"},
    {LCD_COLOR_LIGHTMAGENTA,"LT MAGENTA"}, {LCD_COLOR_LIGHTYELLOW, "LT YELLOW"},
    {LCD_COLOR_DARKBLUE,    "DK BLUE"},    {LCD_COLOR_DARKGREEN,   "DK GREEN"},
    {LCD_COLOR_DARKRED,     "DK RED"},     {LCD_COLOR_DARKCYAN,    "DK CYAN"},
    {LCD_COLOR_DARKMAGENTA, "DK MAGENTA"}, {LCD_COLOR_DARKYELLOW,  "DK YELLOW"},
    {LCD_COLOR_WHITE,       "WHITE"},      {LCD_COLOR_LIGHTGRAY,   "LT GRAY"},
    {LCD_COLOR_GRAY,        "GRAY"},       {LCD_COLOR_DARKGRAY,    "DK GRAY"},
    {LCD_COLOR_BLACK,       "BLACK"},      {LCD_COLOR_BROWN,       "BROWN"},
    {LCD_COLOR_ORANGE,      "ORANGE"}
};
const uint32_t numAvailableColors = sizeof(availableColors) / sizeof(availableColors[0]);

// --- Constants ---
// Main screen elements
#define DRAW_BOX_Y          45
#define DRAW_BOX_BORDER     1
#define OK_CL_BTN_RADIUS    15
#define OK_CL_BTN_Y_OFFSET  20
#define DRAW_BOX_X          ((BSP_LCD_GetXSize() / 2) - (WINDOWS_WITH / 2) - DRAW_BOX_BORDER)
#define OK_CL_BTN_Y         (DRAW_BOX_Y + WINDOWS_HEIGHT + (2 * DRAW_BOX_BORDER) + OK_CL_BTN_Y_OFFSET)
#define CL_BTN_X            (DRAW_BOX_X + WINDOWS_WITH + (2 * DRAW_BOX_BORDER) - OK_CL_BTN_RADIUS - 5)
#define OK_BTN_X            (CL_BTN_X - (2 * OK_CL_BTN_RADIUS) - 15)
// Select Color Button (on main screen)
#define SELECT_COLOR_BTN_WIDTH  120
#define SELECT_COLOR_BTN_HEIGHT 25
#define SELECT_COLOR_BTN_X      ((BSP_LCD_GetXSize() - SELECT_COLOR_BTN_WIDTH) / 2)
#define SELECT_COLOR_BTN_Y      (BSP_LCD_GetYSize() - SELECT_COLOR_BTN_HEIGHT - 5)
// Color Selection Grid Layout
#define COLOR_GRID_BTN_WIDTH     45
#define COLOR_GRID_BTN_HEIGHT    25
#define COLOR_GRID_PADDING_X     8
#define COLOR_GRID_PADDING_Y     8
#define COLOR_GRID_START_X       10
#define COLOR_GRID_START_Y       40
#define COLOR_GRID_COLS          ((BSP_LCD_GetXSize() - COLOR_GRID_START_X * 2 + COLOR_GRID_PADDING_X) / (COLOR_GRID_BTN_WIDTH + COLOR_GRID_PADDING_X))
// Timer frequency --- REMOVED ---
// #define TIMER_FREQ_MHZ      1

// --- Global Variables ---
static uint32_t radius = 4;
float Digit_Data[AI_NETWORK_IN_1_SIZE];
int ai_status;
float predictionval[AI_NETWORK_OUT_1_SIZE];
int class_name_index[AI_NETWORK_OUT_1_SIZE];
const uint8_t* digit_label[]={
    (const uint8_t *)"0", (const uint8_t *)"1", (const uint8_t *)"2", (const uint8_t *)"3", (const uint8_t *)"4",
    (const uint8_t *)"5", (const uint8_t *)"6", (const uint8_t *)"7", (const uint8_t *)"8", (const uint8_t *)"9"
};

static uint32_t currentBackgroundColor = LCD_COLOR_BLACK;
// static uint32_t inference_time_ms = 0; // --- REMOVED ---

// --- Application Buffers for AI ---
AI_ALIGNED(4)
static ai_float app_in_data[AI_NETWORK_IN_1_SIZE];
AI_ALIGNED(4)
static ai_float app_out_data[AI_NETWORK_OUT_1_SIZE];

// --- Forward Declarations ---
void Read_Image(void);
void Convert_To_AIIn_Data(void);
void Display_AI_Output(void);
static void Quicksort(void);
void LCD_Config(void);
void Draw_Menu(void);
void Draw_Color_Selection_Screen(void);
void Set_Background_Color(uint32_t color);
uint16_t Calibration_GetX(uint16_t x);

// --- Quick Sort Helper Functions ---
static void swap(int i, int j) {
    float temp_val = predictionval[i]; predictionval[i] = predictionval[j]; predictionval[j] = temp_val;
    int temp_index = class_name_index[i]; class_name_index[i] = class_name_index[j]; class_name_index[j] = temp_index;
}
static int partition(int low, int high) {
    float pivot = predictionval[high]; int i = (low - 1);
    for (int j = low; j <= high - 1; j++) { if (predictionval[j] <= pivot) { i++; swap(i, j); } }
    swap(i + 1, high); return (i + 1);
}
static void quicksort_recursive(int low, int high) {
    if (low < high) { int pi = partition(low, high); quicksort_recursive(low, pi - 1); quicksort_recursive(pi + 1, high); }
}
static void Quicksort(void) {
    quicksort_recursive(0, AI_NETWORK_OUT_1_SIZE - 1);
}

// --- Function Implementations ---

void LCD_Config(void)
{
  BSP_LCD_Init();
  BSP_LCD_LayerDefaultInit(0, LCD_BUFFER);
  BSP_LCD_SelectLayer(0);
  BSP_LCD_DisplayOn();
  BSP_LCD_SetTransparency(0, 255);
  BSP_LCD_Clear(currentBackgroundColor);
  BSP_LCD_SetFont(&Font12);
  BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
  BSP_LCD_SetBackColor(currentBackgroundColor);
}

void Draw_Menu(void)
{
  BSP_LCD_SelectLayer(0); BSP_LCD_Clear(currentBackgroundColor); BSP_LCD_SetBackColor(currentBackgroundColor);
  BSP_LCD_SetTextColor(LCD_COLOR_YELLOW); BSP_LCD_SetFont(&Font20);
  BSP_LCD_DisplayStringAt(0, 5, (uint8_t*)"B22CS082 B22EE080", CENTER_MODE);
  BSP_LCD_SetFont(&Font12); BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_FillRect(DRAW_BOX_X, DRAW_BOX_Y, WINDOWS_WITH + (2 * DRAW_BOX_BORDER), WINDOWS_HEIGHT + (2 * DRAW_BOX_BORDER));
  BSP_LCD_SetTextColor(LCD_COLOR_WHITE); BSP_LCD_DrawRect(DRAW_BOX_X, DRAW_BOX_Y, WINDOWS_WITH + (2 * DRAW_BOX_BORDER), WINDOWS_HEIGHT + (2 * DRAW_BOX_BORDER));
  BSP_LCD_SetTextColor(LCD_COLOR_WHITE); BSP_LCD_FillCircle(CL_BTN_X, OK_CL_BTN_Y, OK_CL_BTN_RADIUS);
  BSP_LCD_SetBackColor(LCD_COLOR_WHITE); BSP_LCD_SetTextColor(LCD_COLOR_BLACK); BSP_LCD_SetFont(&Font16);
  BSP_LCD_DisplayStringAt(CL_BTN_X - 10, OK_CL_BTN_Y - 8, (uint8_t*)"CL", LEFT_MODE);
  BSP_LCD_SetTextColor(LCD_COLOR_WHITE); BSP_LCD_FillCircle(OK_BTN_X, OK_CL_BTN_Y, OK_CL_BTN_RADIUS);
  BSP_LCD_SetBackColor(LCD_COLOR_WHITE); BSP_LCD_SetTextColor(LCD_COLOR_BLACK); BSP_LCD_SetFont(&Font16);
  BSP_LCD_DisplayStringAt(OK_BTN_X - 10, OK_CL_BTN_Y - 8, (uint8_t*)"OK", LEFT_MODE);
  BSP_LCD_SetFont(&Font12); BSP_LCD_SetTextColor(LCD_COLOR_DARKGRAY);
  BSP_LCD_FillRect(SELECT_COLOR_BTN_X, SELECT_COLOR_BTN_Y, SELECT_COLOR_BTN_WIDTH, SELECT_COLOR_BTN_HEIGHT);
  BSP_LCD_SetBackColor(LCD_COLOR_DARKGRAY); BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
  BSP_LCD_DisplayStringAt(SELECT_COLOR_BTN_X + 5, SELECT_COLOR_BTN_Y + 7, (uint8_t*)"Select Color", LEFT_MODE);
  BSP_LCD_SetTextColor(LCD_COLOR_LIGHTGRAY); BSP_LCD_DrawRect(SELECT_COLOR_BTN_X, SELECT_COLOR_BTN_Y, SELECT_COLOR_BTN_WIDTH, SELECT_COLOR_BTN_HEIGHT);
  BSP_LCD_SetBackColor(currentBackgroundColor); BSP_LCD_SetTextColor(LCD_COLOR_WHITE); BSP_LCD_SetFont(&Font12);
}

void Draw_Color_Selection_Screen(void)
{
    uint16_t i, row, col; uint16_t btn_x, btn_y;
    BSP_LCD_SelectLayer(0); BSP_LCD_Clear(currentBackgroundColor); BSP_LCD_SetBackColor(currentBackgroundColor);
    BSP_LCD_SetTextColor(LCD_COLOR_YELLOW); BSP_LCD_SetFont(&Font12);
    BSP_LCD_DisplayStringAt(0, 10, (uint8_t*)"Select Background Color", CENTER_MODE);
    BSP_LCD_SetFont(&Font12);
    for (i = 0; i < numAvailableColors; i++) {
        col = i % COLOR_GRID_COLS; row = i / COLOR_GRID_COLS;
        btn_x = COLOR_GRID_START_X + col * (COLOR_GRID_BTN_WIDTH + COLOR_GRID_PADDING_X);
        btn_y = COLOR_GRID_START_Y + row * (COLOR_GRID_BTN_HEIGHT + COLOR_GRID_PADDING_Y);
        BSP_LCD_SetTextColor(availableColors[i].colorValue);
        BSP_LCD_FillRect(btn_x, btn_y, COLOR_GRID_BTN_WIDTH, COLOR_GRID_BTN_HEIGHT);
        uint32_t border_color = (availableColors[i].colorValue == LCD_COLOR_BLACK || availableColors[i].colorValue == LCD_COLOR_DARKBLUE || availableColors[i].colorValue == LCD_COLOR_DARKGREEN || availableColors[i].colorValue == LCD_COLOR_DARKRED || availableColors[i].colorValue == LCD_COLOR_DARKGRAY || availableColors[i].colorValue == LCD_COLOR_BROWN ) ? LCD_COLOR_WHITE : LCD_COLOR_DARKGRAY;
        BSP_LCD_SetTextColor(border_color); BSP_LCD_DrawRect(btn_x, btn_y, COLOR_GRID_BTN_WIDTH, COLOR_GRID_BTN_HEIGHT);
    }
    BSP_LCD_SetBackColor(currentBackgroundColor); BSP_LCD_SetTextColor(LCD_COLOR_WHITE); BSP_LCD_SetFont(&Font12);
}

void Set_Background_Color(uint32_t color) {
    if (currentBackgroundColor != color) {
        currentBackgroundColor = color;
        Draw_Menu();
    }
}

void Read_Image(void){
    uint16_t xpos, ypos; uint16_t xsrc, ysrc; uint32_t pixel_color; float avg_intensity; int index = 0;
    uint16_t draw_area_x_start = DRAW_BOX_X + DRAW_BOX_BORDER; uint16_t draw_area_y_start = DRAW_BOX_Y + DRAW_BOX_BORDER;
    uint16_t block_size = 5;
    for(int cell_y = 0; cell_y < 28; ++cell_y) {
        ysrc = draw_area_y_start + cell_y * block_size;
        for(int cell_x = 0; cell_x < 28; ++cell_x) {
            xsrc = draw_area_x_start + cell_x * block_size; uint32_t sum_intensity = 0;
            for(ypos = 0; ypos < block_size; ypos++){
                for(xpos = 0; xpos < block_size; xpos++){
                    uint16_t current_x = xsrc + xpos; uint16_t current_y = ysrc + ypos;
                    if (current_x < BSP_LCD_GetXSize() && current_y < BSP_LCD_GetYSize()) {
                        pixel_color = BSP_LCD_ReadPixel(current_x, current_y);
                        if (pixel_color == LCD_COLOR_WHITE) { sum_intensity += 255; } else { sum_intensity += 0; }
                    } } }
            avg_intensity = (float)sum_intensity / ((float)block_size * block_size * 255.0f);
            if (index < AI_NETWORK_IN_1_SIZE) { Digit_Data[index++] = avg_intensity; } else { break; }
        } if (index >= AI_NETWORK_IN_1_SIZE) break;
    } while (index < AI_NETWORK_IN_1_SIZE) { Digit_Data[index++] = 0.0f; }
}

/**
  * @brief  Handles touch screen input based on the current application state.
  * @param  None
  * @retval None
  */
void Read_TouchPanel(void){
  static TS_StateTypeDef  TS_State;
  uint16_t ts_x_raw, ts_y_raw;
  uint16_t x = 0, y = 0;

  // Variables for time measurement --- REMOVED ---
  // uint16_t start_ticks, end_ticks;
  // uint32_t elapsed_ticks;
  // uint32_t elapsed_us;

  BSP_TS_GetState(&TS_State);
  if (!TS_State.TouchDetected) {
      return;
  }

  ts_x_raw = TS_State.X;
  ts_y_raw = TS_State.Y;
  x = Calibration_GetX(ts_x_raw);
  y = Calibration_GetX(ts_y_raw); // Assume GetX used for Y calibration
  y = BSP_LCD_GetYSize() - 1 - y; // Apply Y-Inversion

  switch (currentAppState) {
      case APP_STATE_MAIN:
          {
              uint16_t draw_box_inner_x = DRAW_BOX_X + DRAW_BOX_BORDER;
              uint16_t draw_box_inner_y = DRAW_BOX_Y + DRAW_BOX_BORDER;
              uint16_t draw_box_inner_width = WINDOWS_WITH;
              uint16_t draw_box_inner_height = WINDOWS_HEIGHT;

              if ( (x > (draw_box_inner_x + radius)) && (y > (draw_box_inner_y + radius)) &&
                   (x < (draw_box_inner_x + draw_box_inner_width - radius)) && (y < (draw_box_inner_y + draw_box_inner_height - radius)) )
              {
                 BSP_LCD_SetBackColor(LCD_COLOR_BLACK); BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
                 BSP_LCD_FillCircle(x, y, radius); BSP_LED_Off(LED4);
              }
              else if ( ((int32_t)(x - CL_BTN_X)*(int32_t)(x - CL_BTN_X) + (int32_t)(y - OK_CL_BTN_Y)*(int32_t)(y - OK_CL_BTN_Y)) < (OK_CL_BTN_RADIUS * OK_CL_BTN_RADIUS) )
              {
                  BSP_LCD_SetTextColor(LCD_COLOR_GRAY); BSP_LCD_FillCircle(CL_BTN_X, OK_CL_BTN_Y, OK_CL_BTN_RADIUS);
                  BSP_LCD_SetBackColor(LCD_COLOR_GRAY); BSP_LCD_SetTextColor(LCD_COLOR_BLACK); BSP_LCD_SetFont(&Font16);
                  BSP_LCD_DisplayStringAt(CL_BTN_X - 10, OK_CL_BTN_Y - 8, (uint8_t*)"CL", LEFT_MODE); HAL_Delay(100);
                  BSP_LCD_SetTextColor(LCD_COLOR_BLACK); BSP_LCD_FillRect(draw_box_inner_x, draw_box_inner_y, draw_box_inner_width, draw_box_inner_height);
                  BSP_LCD_SetTextColor(LCD_COLOR_WHITE); BSP_LCD_FillCircle(CL_BTN_X, OK_CL_BTN_Y, OK_CL_BTN_RADIUS);
                  BSP_LCD_SetBackColor(LCD_COLOR_WHITE); BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                  BSP_LCD_DisplayStringAt(CL_BTN_X - 10, OK_CL_BTN_Y - 8, (uint8_t*)"CL", LEFT_MODE);
                  BSP_LCD_SetTextColor(currentBackgroundColor); BSP_LCD_FillRect(0, OK_CL_BTN_Y + OK_CL_BTN_RADIUS + 5, BSP_LCD_GetXSize(), 60);
                  BSP_LCD_SetFont(&Font12); BSP_LCD_SetBackColor(currentBackgroundColor); BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
              }
              else if ( ((int32_t)(x - OK_BTN_X)*(int32_t)(x - OK_BTN_X) + (int32_t)(y - OK_CL_BTN_Y)*(int32_t)(y - OK_CL_BTN_Y)) < (OK_CL_BTN_RADIUS * OK_CL_BTN_RADIUS) )
              {
                  // --- OK Button Pressed ---
                  BSP_LCD_SetTextColor(LCD_COLOR_GRAY); BSP_LCD_FillCircle(OK_BTN_X, OK_CL_BTN_Y, OK_CL_BTN_RADIUS);
                  BSP_LCD_SetBackColor(LCD_COLOR_GRAY); BSP_LCD_SetTextColor(LCD_COLOR_BLACK); BSP_LCD_SetFont(&Font16);
                  BSP_LCD_DisplayStringAt(OK_BTN_X - 10, OK_CL_BTN_Y - 8, (uint8_t*)"OK", LEFT_MODE); HAL_Delay(100);
                  BSP_LCD_SetTextColor(LCD_COLOR_WHITE); BSP_LCD_FillCircle(OK_BTN_X, OK_CL_BTN_Y, OK_CL_BTN_RADIUS);
                  BSP_LCD_SetBackColor(LCD_COLOR_WHITE); BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                  BSP_LCD_DisplayStringAt(OK_BTN_X - 10, OK_CL_BTN_Y - 8, (uint8_t*)"OK", LEFT_MODE);
                  BSP_LCD_SetFont(&Font12); BSP_LCD_SetBackColor(currentBackgroundColor);
                  BSP_LCD_SetTextColor(currentBackgroundColor); BSP_LCD_FillRect(0, OK_CL_BTN_Y + OK_CL_BTN_RADIUS + 5, BSP_LCD_GetXSize(), 60);
                  BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);

                  // --- AI Processing --- REMOVED TIME MEASUREMENT ---
                  Read_Image();
                  Convert_To_AIIn_Data();
                  ai_status = aiRun(app_in_data, app_out_data);
                  // --- Time calculation removed ---
                  Display_AI_Output(); // Display results WITHOUT time
                  // ----------------------------------------

                  BSP_LCD_SetBackColor(currentBackgroundColor); BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
              }
              else if ( (x >= SELECT_COLOR_BTN_X) && (x < (SELECT_COLOR_BTN_X + SELECT_COLOR_BTN_WIDTH)) &&
                        (y >= SELECT_COLOR_BTN_Y) && (y < (SELECT_COLOR_BTN_Y + SELECT_COLOR_BTN_HEIGHT)) )
              {
                  currentAppState = APP_STATE_COLOR_SELECT; Draw_Color_Selection_Screen(); HAL_Delay(150);
              }
          }
          break; // End APP_STATE_MAIN

      case APP_STATE_COLOR_SELECT:
          {
              uint16_t i, row, col; uint16_t btn_x, btn_y; int button_pressed = -1;
              for (i = 0; i < numAvailableColors; i++) {
                  col = i % COLOR_GRID_COLS; row = i / COLOR_GRID_COLS;
                  btn_x = COLOR_GRID_START_X + col * (COLOR_GRID_BTN_WIDTH + COLOR_GRID_PADDING_X);
                  btn_y = COLOR_GRID_START_Y + row * (COLOR_GRID_BTN_HEIGHT + COLOR_GRID_PADDING_Y);
                  if ((x >= btn_x) && (x < (btn_x + COLOR_GRID_BTN_WIDTH)) && (y >= btn_y) && (y < (btn_y + COLOR_GRID_BTN_HEIGHT))) {
                      button_pressed = i; break;
                  }
              }
              if (button_pressed != -1) {
                  Set_Background_Color(availableColors[button_pressed].colorValue);
                  currentAppState = APP_STATE_MAIN; HAL_Delay(100);
              }
          }
          break; // End APP_STATE_COLOR_SELECT

      default:
          currentAppState = APP_STATE_MAIN; Draw_Menu(); break;
  } // End switch
  BSP_LCD_SetBackColor(currentBackgroundColor);
} // End Read_TouchPanel


/**
  * @brief  Copies the float Digit_Data (0.0-1.0) into app_in_data (ai_float).
  */
void Convert_To_AIIn_Data(void){
    memcpy(app_in_data, Digit_Data, sizeof(ai_float) * AI_NETWORK_IN_1_SIZE);
    // Optional: Map range if needed for model input (e.g., to [-1, 1])
    /* for (int i = 0; i < AI_NETWORK_IN_1_SIZE; i++) { app_in_data[i] = (Digit_Data[i] * 2.0f) - 1.0f; } */
}

/**
  * @brief  Displays the AI prediction result, WITHOUT inference time.
  */
void Display_AI_Output(void){
    uint16_t i;
    uint8_t lcdbfr[64]; // Reduced buffer size slightly
    uint16_t output_y_start = OK_CL_BTN_Y + OK_CL_BTN_RADIUS + 10;

    BSP_LCD_SetFont(&Font20);
    BSP_LCD_SetBackColor(currentBackgroundColor);

    if (ai_status == 0) { // AI Run Success
        BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);
        BSP_LCD_DisplayStringAt(2, output_y_start, (uint8_t*)"OUTPUT:", LEFT_MODE);

        for(i = 0; i < AI_NETWORK_OUT_1_SIZE; i++){
            predictionval[i] = app_out_data[i] * 100.0f; // Convert to percentage
            class_name_index[i] = i; // Initialize index for sorting
        }
        Quicksort(); // Sort predictions

        uint16_t current_y = output_y_start + 25;
        // Format string to include prediction ONLY
        snprintf((char*)lcdbfr, sizeof(lcdbfr), "%s (%.1f%%)", // Removed time format
                 digit_label[class_name_index[AI_NETWORK_OUT_1_SIZE - 1]], // Index of highest score
                 predictionval[AI_NETWORK_OUT_1_SIZE - 1]);                // Value of highest score
        BSP_LCD_DisplayStringAt(2, current_y, (uint8_t*)lcdbfr, LEFT_MODE);

    } else { // AI Run Error
        BSP_LCD_SetTextColor(LCD_COLOR_RED);
        snprintf((char*)lcdbfr, sizeof(lcdbfr), "AI ERROR: %d", ai_status);
        BSP_LCD_DisplayStringAt(2, output_y_start, (uint8_t*)lcdbfr, LEFT_MODE);
    }

    BSP_LCD_SetFont(&Font12);
    BSP_LCD_SetBackColor(currentBackgroundColor);
    BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
}

/**
  * @brief Sorts the prediction values using Quick Sort.
  */
// Quick Sort implementation (swap, partition, quicksort_recursive, Quicksort) remains the same
