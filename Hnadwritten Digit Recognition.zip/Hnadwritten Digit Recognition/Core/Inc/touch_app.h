// Core/Inc/touch_app.h
#ifndef INC_TOUCH_APP_H_
#define INC_TOUCH_APP_H_

#include "global.h" // Include dependencies

// Function Prototypes
void LCD_Config(void);
void Draw_Menu(void);
void Draw_Color_Selection_Screen(void);
void Read_TouchPanel(void);
void Set_Background_Color(uint32_t color);
void Read_Image(void);
void Convert_To_AIIn_Data(void);
void Display_AI_Output(void);
// Add other prototypes if they are called from outside touch_app.c

#endif /* INC_TOUCH_APP_H_ */
